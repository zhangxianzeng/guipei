package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
@XStreamAlias("UnavailablePeriodPenaltyTeacher")
public class UnavailablePeriodPenaltyTeacher extends AbstractPersistable{
 private Teacher teacher;
 private Period period;
public Teacher getTeacher() {
	return teacher;
}
public void setTeacher(Teacher teacher) {
	this.teacher = teacher;
}
public Period getPeriod() {
	return period;
}
public void setPeriod(Period period) {
	this.period = period;
}
@Override
public String toString() {
    return teacher + "@" + period;
}
}
